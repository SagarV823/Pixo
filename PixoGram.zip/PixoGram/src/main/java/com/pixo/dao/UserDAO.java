package com.pixo.dao;

import com.pixo.bean.User;

public interface UserDAO {

	public boolean registerUser(User user);
	public boolean authenticate(String email,String password);
	public User getUser(String email);
}
